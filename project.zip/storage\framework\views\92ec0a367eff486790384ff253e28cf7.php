<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dasbor UMKM Kopi</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50 flex">

    <!-- SIDEBAR -->
    <aside class="w-64 bg-gray-900 text-white min-h-screen flex flex-col justify-between">
        <div>
            <div class="p-6 font-bold text-xl flex items-center gap-2">
                <i class="fas fa-coffee text-amber-500"></i> UMKM Kopi
            </div>
            <nav class="mt-4 px-4 space-y-2">
                <a href="<?php echo e(route('dashboard')); ?>" class="block bg-amber-700 p-3 rounded-lg"><i class="fas fa-chart-pie mr-2"></i> Dasbor Utama</a>
                <a href="<?php echo e(route('menu.index')); ?>" class="block p-3 hover:bg-gray-800 rounded-lg"><i class="fas fa-mug-hot mr-2"></i> Menu Kopi & Produk</a>
                <a href="<?php echo e(route('kategori.index')); ?>" class="block p-3 hover:bg-gray-800 rounded-lg"><i class="fas fa-tag mr-2"></i> Kategori Menu</a>
                <a href="<?php echo e(route('pesanan.index')); ?>" class="block p-3 hover:bg-gray-800 rounded-lg"><i class="fas fa-receipt mr-2"></i> Pesanan Masuk</a>
                <a href="<?php echo e(route('laporan.index')); ?>" class="block p-3 hover:bg-gray-800 rounded-lg"><i class="fas fa-wallet mr-2"></i> Laporan Keuangan</a>
            </nav>
        </div>

        <div class="p-4 border-t border-gray-800">
            <form action="<?php echo e(route('logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="w-full text-left p-3 hover:bg-red-900 rounded-lg text-red-400">
                    <i class="fas fa-sign-out-alt mr-2"></i> Keluar Sistem
                </button>
            </form>
        </div>
    </aside>

    <!-- MAIN CONTENT -->
    <main class="flex-1 p-8 overflow-auto">
        <h1 class="text-3xl font-bold mb-8">Dashboard UMKM Kopi</h1>

        <!-- KEY METRICS -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div class="bg-white p-6 rounded-lg shadow border-l-4 border-blue-500">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm">Total Menu Produk</p>
                        <p class="text-3xl font-bold text-blue-600"><?php echo e($total_menu); ?></p>
                    </div>
                    <i class="fas fa-box text-4xl text-blue-100"></i>
                </div>
            </div>

            <div class="bg-white p-6 rounded-lg shadow border-l-4 border-green-500">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm">Total Stok Produk</p>
                        <p class="text-3xl font-bold text-green-600"><?php echo e($total_stok_produk); ?> unit</p>
                    </div>
                    <i class="fas fa-cubes text-4xl text-green-100"></i>
                </div>
            </div>

            <div class="bg-white p-6 rounded-lg shadow border-l-4 border-amber-500">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm">Total Transaksi</p>
                        <p class="text-3xl font-bold text-amber-600"><?php echo e($total_transaksi); ?></p>
                    </div>
                    <i class="fas fa-receipt text-4xl text-amber-100"></i>
                </div>
            </div>

            <div class="bg-white p-6 rounded-lg shadow border-l-4 border-purple-500">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm">Total Pendapatan</p>
                        <p class="text-2xl font-bold text-purple-600">Rp <?php echo e(number_format($total_pendapatan, 0, ',', '.')); ?></p>
                    </div>
                    <i class="fas fa-money-bill-wave text-4xl text-purple-100"></i>
                </div>
            </div>
        </div>

        <!-- SALES TIMELINE -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div class="bg-gradient-to-br from-orange-50 to-orange-100 p-6 rounded-lg shadow border border-orange-200">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-orange-700 font-semibold">Penjualan Hari Ini</p>
                        <p class="text-2xl font-bold text-orange-900">Rp <?php echo e(number_format($hari_ini, 0, ',', '.')); ?></p>
                    </div>
                    <i class="fas fa-calendar-day text-4xl text-orange-200"></i>
                </div>
            </div>

            <div class="bg-gradient-to-br from-cyan-50 to-cyan-100 p-6 rounded-lg shadow border border-cyan-200">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-cyan-700 font-semibold">Penjualan Minggu Ini</p>
                        <p class="text-2xl font-bold text-cyan-900">Rp <?php echo e(number_format($minggu_ini, 0, ',', '.')); ?></p>
                    </div>
                    <i class="fas fa-calendar-week text-4xl text-cyan-200"></i>
                </div>
            </div>

            <div class="bg-gradient-to-br from-pink-50 to-pink-100 p-6 rounded-lg shadow border border-pink-200">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-pink-700 font-semibold">Penjualan Bulan Ini</p>
                        <p class="text-2xl font-bold text-pink-900">Rp <?php echo e(number_format($bulan_ini, 0, ',', '.')); ?></p>
                    </div>
                    <i class="fas fa-calendar-alt text-4xl text-pink-200"></i>
                </div>
            </div>
        </div>

        <!-- SYSTEM INSIGHTS -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <!-- INSIGHT 1: PRODUK TERLARIS -->
            <div class="bg-white p-6 rounded-lg shadow border-t-4 border-green-500">
                <h2 class="text-lg font-bold mb-4 text-gray-800">
                    <i class="fas fa-star text-yellow-500 mr-2"></i>Produk Terlaris (Best Seller)
                </h2>
                <?php if($insight_terlaris): ?>
                    <div class="bg-green-50 p-4 rounded border border-green-200">
                        <div class="mb-3">
                            <p class="text-gray-600 text-sm">Produk</p>
                            <p class="text-xl font-bold text-gray-900"><?php echo e($insight_terlaris['produk']->nama_kopi); ?></p>
                        </div>
                        <div class="grid grid-cols-3 gap-3">
                            <div class="bg-white p-2 rounded">
                                <p class="text-gray-500 text-xs">Total Terjual</p>
                                <p class="text-lg font-bold text-green-600"><?php echo e($insight_terlaris['total_qty']); ?> unit</p>
                            </div>
                            <div class="bg-white p-2 rounded">
                                <p class="text-gray-500 text-xs">Total Omzet</p>
                                <p class="text-sm font-bold text-green-600">Rp <?php echo e(number_format($insight_terlaris['total_omzet'], 0, ',', '.')); ?></p>
                            </div>
                            <div class="bg-white p-2 rounded">
                                <p class="text-gray-500 text-xs">Kontribusi</p>
                                <p class="text-lg font-bold text-green-600"><?php echo e($insight_terlaris['kontribusi_persen']); ?>%</p>
                            </div>
                        </div>
                        <p class="text-xs text-gray-500 mt-3">Data periode: <?php echo e($insight_terlaris['periode_hari']); ?> hari terakhir</p>
                    </div>
                <?php else: ?>
                    <p class="text-gray-500 text-center py-4">Belum ada data transaksi</p>
                <?php endif; ?>
            </div>

            <!-- INSIGHT 2: STOK MENIPIS -->
            <div class="bg-white p-6 rounded-lg shadow border-t-4 border-red-500">
                <h2 class="text-lg font-bold mb-4 text-gray-800">
                    <i class="fas fa-exclamation-triangle text-red-500 mr-2"></i>Status Stok (Menipis)
                </h2>
                <?php if($insight_stok_menipis && $insight_stok_menipis->count() > 0): ?>
                    <div class="space-y-2">
                        <?php $__currentLoopData = $insight_stok_menipis->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-red-50 p-3 rounded border border-red-200 flex justify-between items-center">
                            <div>
                                <p class="font-semibold text-gray-900"><?php echo e($produk->nama_kopi); ?></p>
                                <p class="text-sm text-red-600">Stok: <strong><?php echo e($produk->stok); ?> unit</strong></p>
                            </div>
                            <span class="bg-red-200 text-red-800 px-3 py-1 rounded-full text-xs font-bold">⚠️ KRITIS</span>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <p class="text-gray-500 text-center py-4 text-green-600">✓ Semua stok normal</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- RECOMMENDATIONS -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <!-- RECOMMENDATION 1: RESTOCK -->
            <div class="bg-white p-6 rounded-lg shadow border-t-4 border-blue-500">
                <h2 class="text-lg font-bold mb-4 text-gray-800">
                    <i class="fas fa-lightbulb text-blue-500 mr-2"></i>Rekomendasi Restock
                </h2>
                <?php if(count($rekomendasi_restock) > 0): ?>
                    <div class="space-y-3">
                        <?php $__currentLoopData = $rekomendasi_restock->take(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-blue-50 p-4 rounded border border-blue-200">
                            <p class="font-bold text-gray-900 mb-2"><?php echo e($item['produk']->nama_kopi); ?></p>
                            <p class="text-sm text-gray-700 mb-2"><?php echo e($item['pesan']); ?></p>
                            <div class="bg-blue-100 p-2 rounded text-xs font-semibold text-blue-900">
                                💡 Rekomendasi: Stok masuk <?php echo e($item['qty_disarankan']); ?> unit
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <p class="text-gray-500 text-center py-4">Tidak ada rekomendasi restock saat ini</p>
                <?php endif; ?>
            </div>

            <!-- RECOMMENDATION 2: PROMOSI -->
            <div class="bg-white p-6 rounded-lg shadow border-t-4 border-amber-500">
                <h2 class="text-lg font-bold mb-4 text-gray-800">
                    <i class="fas fa-megaphone text-amber-500 mr-2"></i>Rekomendasi Promosi
                </h2>
                <?php if(count($rekomendasi_promosi) > 0): ?>
                    <div class="space-y-3">
                        <?php $__currentLoopData = $rekomendasi_promosi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-amber-50 p-4 rounded border border-amber-200">
                            <p class="font-bold text-gray-900 mb-2"><?php echo e($item['produk']->nama_kopi); ?></p>
                            <p class="text-sm text-gray-700 mb-2"><?php echo e($item['pesan']); ?></p>
                            <div class="bg-amber-100 p-2 rounded text-xs font-semibold text-amber-900">
                                🎯 Aksi: Terapkan strategi promosi bundling
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <p class="text-gray-500 text-center py-4">Tidak ada rekomendasi promosi saat ini</p>
                <?php endif; ?>
            </div>
        </div>
    </main>

</body>
</html>
<?php /**PATH C:\belajar\project-belajar\smart-catalog-umkm\resources\views/dashboard.blade.php ENDPATH**/ ?>