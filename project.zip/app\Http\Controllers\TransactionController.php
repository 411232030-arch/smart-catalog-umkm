<?php

namespace App\Http\Controllers;

use App\Models\Produk;
use App\Models\StokMasuk;
use App\Models\TransaksiPenjualan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TransactionController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Halaman utama fitur transaksi: form + riwayat penjualan & stok masuk.
     */
    public function index()
    {
        $produkList = Produk::orderBy('nama_kopi')->get();

        $riwayatPenjualan = TransaksiPenjualan::with('produk')
            ->orderByDesc('tanggal')
            ->limit(15)
            ->get();

        $riwayatStokMasuk = StokMasuk::with('produk')
            ->orderByDesc('tanggal')
            ->limit(15)
            ->get();

        return view('dashboard_features.pesanan', compact('produkList', 'riwayatPenjualan', 'riwayatStokMasuk'));
    }

    /**
     * Simpan transaksi penjualan (sales).
     * Kriteria: Nomor Transaksi, Tanggal (auto), Produk, Qty, Merchant Code.
     */
    public function storePenjualan(Request $request)
    {
        $validated = $request->validate([
            'produk_id' => 'required|exists:produk,id',
            'qty' => 'required|integer|min:1',
            'merchant_code' => 'required|string|max:50',
        ]);

        return DB::transaction(function () use ($validated) {
            $produk = Produk::lockForUpdate()->findOrFail($validated['produk_id']);

            if ($produk->stok < $validated['qty']) {
                return back()
                    ->withInput()
                    ->with('error', "Stok \"{$produk->nama_kopi}\" tidak mencukupi. Sisa stok: {$produk->stok}.");
            }

            $nomorTransaksi = $this->generateCode('TRX', TransaksiPenjualan::class, 'nomor_transaksi');

            TransaksiPenjualan::create([
                'nomor_transaksi' => $nomorTransaksi,
                'tanggal' => now(),
                'produk_id' => $produk->id,
                'qty' => $validated['qty'],
                'merchant_code' => $validated['merchant_code'],
                'harga_satuan' => $produk->harga,
                'total_harga' => $produk->harga * $validated['qty'],
            ]);

            $produk->decrement('stok', $validated['qty']);

            return redirect()->route('pesanan.index')
                ->with('success', "Transaksi penjualan {$nomorTransaksi} berhasil dicatat.");
        });
    }

    /**
     * Simpan transaksi stok masuk (incoming stock).
     * Kriteria: Stock Code, Tanggal (auto), Produk, Qty.
     */
    public function storeStokMasuk(Request $request)
    {
        $validated = $request->validate([
            'produk_id' => 'required|exists:produk,id',
            'qty' => 'required|integer|min:1',
        ]);

        return DB::transaction(function () use ($validated) {
            $produk = Produk::lockForUpdate()->findOrFail($validated['produk_id']);

            $stockCode = $this->generateCode('STK', StokMasuk::class, 'stock_code');

            StokMasuk::create([
                'stock_code' => $stockCode,
                'tanggal' => now(),
                'produk_id' => $produk->id,
                'qty' => $validated['qty'],
            ]);

            $produk->increment('stok', $validated['qty']);

            return redirect()->route('pesanan.index')
                ->with('success', "Stok masuk {$stockCode} berhasil dicatat, stok \"{$produk->nama_kopi}\" bertambah {$validated['qty']} unit.");
        });
    }

    /**
     * Generate kode berurutan harian, misal: TRX-20260710-0001 / STK-20260710-0001
     */
    protected function generateCode(string $prefix, string $model, string $column): string
    {
        $today = now()->format('Ymd');

        $countToday = $model::whereDate('created_at', now()->toDateString())->count();

        $urut = str_pad((string) ($countToday + 1), 4, '0', STR_PAD_LEFT);

        return "{$prefix}-{$today}-{$urut}";
    }
}
